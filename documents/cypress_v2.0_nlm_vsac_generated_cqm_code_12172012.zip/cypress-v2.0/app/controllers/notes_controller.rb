class NotesController < ApplicationController
  layout nil

  
end