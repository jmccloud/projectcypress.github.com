
class PatientPopulationsController < ApplicationController
  before_filter :authenticate_user!

end
