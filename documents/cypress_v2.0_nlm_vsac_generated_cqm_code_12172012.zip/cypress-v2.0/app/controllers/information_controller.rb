require 'version'
class InformationController < ApplicationController

end