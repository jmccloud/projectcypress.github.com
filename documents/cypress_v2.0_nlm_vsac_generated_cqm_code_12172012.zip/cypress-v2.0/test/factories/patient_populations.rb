FactoryGirl.define do
  
  
end

