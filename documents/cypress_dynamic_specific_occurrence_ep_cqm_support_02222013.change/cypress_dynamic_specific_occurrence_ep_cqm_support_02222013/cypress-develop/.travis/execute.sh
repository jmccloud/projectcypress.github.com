cp ./.travis/mongoid.yml ./config/mongoid.yml
bundle exec rake test
