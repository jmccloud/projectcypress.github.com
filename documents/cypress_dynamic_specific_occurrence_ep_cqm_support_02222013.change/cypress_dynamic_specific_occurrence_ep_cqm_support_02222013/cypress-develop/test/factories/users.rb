FactoryGirl.define do
  
  factory :bobby do 
    first_name  "bobby"
    last_name  "tables"
    telephone "867-5309"
    email   "bobby@tables.org"
    # "product_ids":["4f6b77831d41c851eb0004a5""4f636ae01d41c851eb00048e""4f57a88a1d41c851eb000004"]
    #     product_test_ids :["4f6b78801d41c851eb0004a7""4f5a606b1d41c851eb000484""4f636b3f1d41c851eb000491""4f58f8de1d41c851eb000478"]
  end
  
end